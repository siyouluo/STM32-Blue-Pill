Instructions for using Artistic Style are included in the *doc* directory.

The file **install.html** contains instructions for compiling and
installing Artistic Style.

The file **astyle.html**' contains information on using Artistic Style.

The files **news.html** and **notes.html** contain information on changes
made to the various releases.
